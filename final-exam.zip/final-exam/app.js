const express = require('express');
const router = express.Router();
const Mongo = require('mongodb').MongoClient;

app = express();

const dburl = 'mongodb://localhost/27017/RPS';
// Mongo.connect(dburl, (err, db)=> {
//     // assert.equal(null,err);
//     db.collection('statistics').insertOne({},(err,result) =>{
//         // assert.equal(null,err);
//         console.log('item inserted');
//     })
// });
/* THIS CODE MAY BE USED TO RETRIEVE THE RESPONSE CODE FROM ANOTHER FILE
app.use("/", (req, res) => {
 res.sendFile(__dirname + "/index.html");
}); 
*/

app.get('/', (req, res) => {
    res.send(`ROCK PAPER SCISSORS!!!!!!!!!
    <br>
    Enter your name here:
    <br>
    <form  method='POST'>
    <input type='text' placeholder="name">
    <button type ='enter'>Enter</button>
    </form>
    Select rock, paper or scissors

    <button type='enter' onclick = 'rockFunction()'>Rock</button>
    <button type='enter' onclick = 'paperFunction()'>Paper</button>
    <button type='enter' onclick = 'scissorsFunction()'>Scissors</button>

    <script>
        let wins = 0;
        let losses = 0;
        oneorzero = Math.random() < 0.5 ? 0:1
        
        function rockFunction() {
            if(oneorzero == 0){
                alert('CPU picked scissors, you win!'); 
                wins +=1;
                alert('wins: ' + wins + 'losses: ' + losses );
                
            }
            else {
                alert('CPU picked paper, you lose.'); 
                losses +=1;
                alert('wins: ' + wins + 'losses: ' + losses );
                }
            }    
        function paperFunction() {
            if(oneorzero == 0){
                alert('CPU picked rock, you win!'); 
                wins +=1;
                alert('wins: ' + wins + 'losses: ' + losses );
            }
            else {
                alert('CPU picked scissors, you lose.'); 
                losses +=1;
                alert('wins: ' + wins + 'losses: ' + losses );
                }
            }
        function scissorsFunction() {
            if(oneorzero == 0){
                alert('CPU picked scissors, you win!'); 
                wins +=1;
                alert('wins: ' + wins + 'losses: ' + losses );
            }
            else {
                alert('CPU picked rock, you lose.'); 
                losses +=1;
                alert('wins: ' + wins + 'losses: ' + losses );
                }
            }    
    </script>
    
    `)
})

app.post('/quotes', (req, res) => {
    console.log('Hellooooooooooooooooo!')
  })



const PORT = 5000;

app.listen(PORT, ()=> {console.log(`Listening at port:${PORT}`)

})